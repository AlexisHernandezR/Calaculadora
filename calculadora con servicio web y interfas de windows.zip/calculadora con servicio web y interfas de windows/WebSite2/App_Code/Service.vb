﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols

<WebService(Namespace:="http://tempuri.org/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class Service
     Inherits System.Web.Services.WebService

    <WebMethod()> _
    Public Function Suma(ByVal Valor1 As Integer, ByVal Valor2 As Integer) As Integer
        Dim Resultado As Integer
        Resultado = Valor1 + Valor2
        Return Resultado
    End Function
    <WebMethod()> _
    Public Function Resta(ByVal Valor1 As Integer, ByVal Valor2 As Integer) As Integer
        Dim Resultado As Integer
        Resultado = Valor1 - Valor2
        Return Resultado
    End Function
    <WebMethod()> _
    Public Function Suma2(ByVal Valor1 As Integer, ByVal Valor2 As Integer) As String
        Dim Resultado As Integer
        Resultado = Valor1 + Valor2
        Return "El resultado es:" & CStr(Resultado)
    End Function
    <WebMethod()> _
    Public Function Multiplicacion(ByVal Valor1 As Integer, ByVal Valor2 As Integer) As Integer
        Dim Resultado As Integer
        Resultado = Valor1 * Valor2
        Return Resultado
    End Function

    <WebMethod()> _
    Public Function Division(ByVal Valor1 As Integer, ByVal Valor2 As Integer) As Integer
        Dim Resultado As Integer
        Resultado = Valor1 / Valor2
        Return Resultado
    End Function

End Class