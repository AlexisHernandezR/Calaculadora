﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txbValor1 = New System.Windows.Forms.TextBox()
        Me.txbValor2 = New System.Windows.Forms.TextBox()
        Me.btnSuma = New System.Windows.Forms.Button()
        Me.Resultado = New System.Windows.Forms.TextBox()
        Me.btnResta = New System.Windows.Forms.Button()
        Me.btnMultiplicacion = New System.Windows.Forms.Button()
        Me.btnDivision = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "VALOR 1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "VALOR 2"
        '
        'txbValor1
        '
        Me.txbValor1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbValor1.Location = New System.Drawing.Point(116, 14)
        Me.txbValor1.Name = "txbValor1"
        Me.txbValor1.Size = New System.Drawing.Size(100, 30)
        Me.txbValor1.TabIndex = 2
        '
        'txbValor2
        '
        Me.txbValor2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txbValor2.Location = New System.Drawing.Point(116, 56)
        Me.txbValor2.Name = "txbValor2"
        Me.txbValor2.Size = New System.Drawing.Size(100, 30)
        Me.txbValor2.TabIndex = 3
        '
        'btnSuma
        '
        Me.btnSuma.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btnSuma.Location = New System.Drawing.Point(12, 101)
        Me.btnSuma.Name = "btnSuma"
        Me.btnSuma.Size = New System.Drawing.Size(64, 43)
        Me.btnSuma.TabIndex = 4
        Me.btnSuma.Text = "Suma"
        Me.btnSuma.UseVisualStyleBackColor = False
        '
        'Resultado
        '
        Me.Resultado.Font = New System.Drawing.Font("Microsoft Sans Serif", 28.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Resultado.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Resultado.Location = New System.Drawing.Point(12, 165)
        Me.Resultado.Name = "Resultado"
        Me.Resultado.Size = New System.Drawing.Size(274, 61)
        Me.Resultado.TabIndex = 5
        Me.Resultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnResta
        '
        Me.btnResta.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btnResta.Location = New System.Drawing.Point(82, 101)
        Me.btnResta.Name = "btnResta"
        Me.btnResta.Size = New System.Drawing.Size(64, 43)
        Me.btnResta.TabIndex = 6
        Me.btnResta.Text = "Resta"
        Me.btnResta.UseVisualStyleBackColor = False
        '
        'btnMultiplicacion
        '
        Me.btnMultiplicacion.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btnMultiplicacion.Location = New System.Drawing.Point(152, 101)
        Me.btnMultiplicacion.Name = "btnMultiplicacion"
        Me.btnMultiplicacion.Size = New System.Drawing.Size(64, 43)
        Me.btnMultiplicacion.TabIndex = 7
        Me.btnMultiplicacion.Text = "Mult"
        Me.btnMultiplicacion.UseVisualStyleBackColor = False
        '
        'btnDivision
        '
        Me.btnDivision.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btnDivision.Location = New System.Drawing.Point(222, 101)
        Me.btnDivision.Name = "btnDivision"
        Me.btnDivision.Size = New System.Drawing.Size(64, 43)
        Me.btnDivision.TabIndex = 8
        Me.btnDivision.Text = "Div"
        Me.btnDivision.UseVisualStyleBackColor = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(302, 253)
        Me.Controls.Add(Me.btnDivision)
        Me.Controls.Add(Me.btnMultiplicacion)
        Me.Controls.Add(Me.btnResta)
        Me.Controls.Add(Me.Resultado)
        Me.Controls.Add(Me.btnSuma)
        Me.Controls.Add(Me.txbValor2)
        Me.Controls.Add(Me.txbValor1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txbValor1 As System.Windows.Forms.TextBox
    Friend WithEvents txbValor2 As System.Windows.Forms.TextBox
    Friend WithEvents btnSuma As System.Windows.Forms.Button
    Friend WithEvents Resultado As System.Windows.Forms.TextBox
    Friend WithEvents btnResta As System.Windows.Forms.Button
    Friend WithEvents btnMultiplicacion As System.Windows.Forms.Button
    Friend WithEvents btnDivision As System.Windows.Forms.Button

End Class
