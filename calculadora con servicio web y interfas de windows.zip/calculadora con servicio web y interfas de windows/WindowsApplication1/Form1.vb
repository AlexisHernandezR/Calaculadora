﻿Public Class Form1


    Private Sub btnSuma_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSuma.Click
        Dim objOperation As New localhost.Service
        Me.Resultado.Text = objOperation.Suma(Me.txbValor1.Text, Me.txbValor2.Text)
    End Sub

    Private Sub btnResta_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResta.Click
        Dim objOperation As New localhost.Service
        Me.Resultado.Text = objOperation.Resta(Me.txbValor1.Text, Me.txbValor2.Text)
    End Sub

    Private Sub btnMultiplicacion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMultiplicacion.Click
        Dim objOperation As New localhost.Service
        Me.Resultado.Text = objOperation.Multiplicacion(Me.txbValor1.Text, Me.txbValor2.Text)
    End Sub

    Private Sub btnDivision_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDivision.Click
        Dim objOperation As New localhost.Service
        Me.Resultado.Text = objOperation.Division(Me.txbValor1.Text, Me.txbValor2.Text)
    End Sub
End Class
